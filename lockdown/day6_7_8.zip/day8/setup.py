from setuptools import setup

setup(name='App', version='1.2', description="a new package", url='#', author='nigam', packages=['App'])