def add(la, lb):
    return la+lb

def avg(la, lb):
    return (la+lb)/2

def square(la):
    return la**2