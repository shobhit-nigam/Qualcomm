def funcx():
    print("hello from x")
    
vara = 33