from .. import calculations

def funcy():
    print("inside y")
    x = calculations.add(4, 6)
    print(x)