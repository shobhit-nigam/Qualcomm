from .calculations import add, square
from .one import funcx
from .inner import two