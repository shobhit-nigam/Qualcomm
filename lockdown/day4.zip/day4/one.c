#include<stdio.h>

void main()
	{
	int varx = 33;
	printf("hello world\n");
	printf("varx = %d\n, varx);
	}
