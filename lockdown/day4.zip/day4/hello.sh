pwd
echo "hello"
sleep 4
clear
qualcomm
sleep 4
ls
