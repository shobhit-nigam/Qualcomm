print("hi")
