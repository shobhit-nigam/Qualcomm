"""karthikeyan's module
has functions like red, orange, yellow"""

import vijayakumar

def yellow():
    print("yellow fellow")
    
def red():
    print("scarlet red")
    
def orange():
    print("orange is a mixture of:")
    red()
    yellow()
    
if __name__ == "__main__":
    print("this is a primary application")
    
    def vibgyor():
        print("all colours")
else:
    print("this is being used as a module")
    def vibgyor():
        print("only 7 colours")    
        
        
vibgyor()
        
        
        
        
        
