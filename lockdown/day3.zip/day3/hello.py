"""testing a python file"""

def funca():
	print("hello py")

funca()
