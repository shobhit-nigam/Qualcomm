def red():
    print("crimson red")
    
def blue():
    print("cool blue")
    
data1 = 30
data2= 50

def green():
    print("go green")